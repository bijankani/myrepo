define( function ( require ) {

	"use strict";

	return {
		app_slug : 'wp-appkit-tutorial',
		wp_ws_url : 'http://www.azzaman.com/azzamanmobile/wp-appkit-api/wp-appkit-tutorial',
		wp_url : 'http://www.azzaman.com/azzamanmobile',
		theme : 'q-android',
		version : '1.0',
		app_title : 'azzaman',
		app_platform : 'android',
		gmt_offset : 1,
		debug_mode : 'off',
		auth_key : 'qwYs~Y8[V)rU[@-J;tc&b^7rme |2+D|jygoR;Gx5Yex{mTmGBR0^]8t|*+*qy6[',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
